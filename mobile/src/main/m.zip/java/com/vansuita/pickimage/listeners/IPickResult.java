package com.vansuita.pickimage.listeners;

import com.vansuita.pickimage.bean.PickResult;

/**
 * Created by jrvansuita build 02/12/16.
 */

public interface IPickResult {
    void onPickResult(PickResult r);
}
