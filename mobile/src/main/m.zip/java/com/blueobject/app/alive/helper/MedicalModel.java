package com.blueobject.app.alive.helper;

/**
 * Created by nrgie on 2017.07.30..
 */

public class MedicalModel {
    public String name = "";
    public String date = "";
}

