package com.blueobject.app.alive.dialog;

import android.support.v4.app.DialogFragment;

public class Error_Dialog extends DialogFragment {
}
