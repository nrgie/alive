package com.blueobject.app.alive.dialog;

import android.support.v4.app.DialogFragment;

public class SignIn_Dialog extends DialogFragment {
}
