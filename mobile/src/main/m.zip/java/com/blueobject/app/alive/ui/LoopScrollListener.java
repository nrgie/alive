package com.blueobject.app.alive.ui;


public interface LoopScrollListener {
    void onItemSelect(int item);
}
