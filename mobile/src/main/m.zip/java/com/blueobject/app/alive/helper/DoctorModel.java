package com.blueobject.app.alive.helper;

/**
 * Created by nrgie on 2017.07.30..
 */

public class DoctorModel {
    public String name = "";
    public String email = "";
    public String phone = "";
    public String special = "";
    public String custom = "";
}

