package com.blueobject.app.alive.helper;

/**
 * Created by nrgie on 2017.09.11..
 */

public class ProtectedModel {

    public String name = "";
    public String email = "";
    public String lat = "";
    public String lng = "";

}