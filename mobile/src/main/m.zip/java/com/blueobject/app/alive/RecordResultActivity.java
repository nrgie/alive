package com.blueobject.app.alive;

/**
 * Created by nrgie on 2017.08.31..
 */

public class RecordResultActivity {
}
