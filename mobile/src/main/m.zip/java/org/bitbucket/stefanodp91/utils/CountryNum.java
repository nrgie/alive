package org.bitbucket.stefanodp91.utils;

/**
 * Created by nrgie on 2017.07.30..
 */

public class CountryNum {

    public String A = "";
    public String P = "";
    public String F = "";
    public String C = "";
    public boolean M112 = false;

}
